export class CreateCurrencyTypeDto {
    name: string;
    description: string;
}
