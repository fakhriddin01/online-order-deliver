export class CreateAdminDto {
    username: string;
    password: string;
}
