export class CreateStatusDto {
    name: string;
    description: string;
}
