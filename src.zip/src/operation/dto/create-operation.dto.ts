export class CreateOperationDto {
    order_id: string;
    status_id: string;
    admin_id: string;
    operation_date: Date;
    description?: string;
}
